module.exports = {
	useTabs: true,
	trailingComma: "none",
	arrowParens: "avoid",
	endOfLine: "auto",
	printWidth: 120
};
